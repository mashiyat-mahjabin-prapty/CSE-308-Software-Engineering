import java.io.IOException;

public class bankMain {
    public static void main(String[] args) throws IOException {
        bank Bank = new bank();
        Bank.driver();
    }
}
