package Problem_1.Display_Controller.Display_System;

public class LCD extends Display_System {

    public LCD()
    {
        //System.out.println("A new LCD display unit created");
    }

    public double getPrice()
    {
        return 11.0;
    }

    public String getName()
    {
        return "LCD";
    }
}
