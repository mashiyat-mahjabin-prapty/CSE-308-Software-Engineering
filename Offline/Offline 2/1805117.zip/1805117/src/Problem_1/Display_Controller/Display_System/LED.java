package Problem_1.Display_Controller.Display_System;

public class LED extends Display_System {
    public LED()
    {
        //System.out.println("A new LED display unit created");
    }

    public double getPrice()
    {
        return 16.0;
    }

    public String getName()
    {
        return "LED";
    }
}
