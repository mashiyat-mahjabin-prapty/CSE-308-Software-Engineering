package Problem_1.Display_Controller.Processor;

public class ATMega32 extends Processor {
    public ATMega32()
    {
        //System.out.println("An ATMega32 controller created");
    }

    public String getProcessor_name()
    {
        return "ATMega32";
    }
    public double getProcessor_cost()
    {
        return 150.0;
    }
}
