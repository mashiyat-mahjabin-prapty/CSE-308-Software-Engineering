package Problem_1.Display_Controller.Processor;

public class RPi extends Processor {
    public String getProcessor_name()
    {
        return "Raspberry Pi";
    }
    public double getProcessor_cost()
    {
        return 550.0;
    }
}
