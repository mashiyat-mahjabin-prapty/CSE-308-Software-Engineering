package Problem_2.Font;

public class Consolas implements Font{

    @Override
    public String getName() {
        return "Consolas";
    }

    @Override
    public String toString() {
        return "Font: Consolas";
    }
}
