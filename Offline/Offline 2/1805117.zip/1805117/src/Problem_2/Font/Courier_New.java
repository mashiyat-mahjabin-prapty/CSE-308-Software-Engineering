package Problem_2.Font;

public class Courier_New implements Font{
    @Override
    public String getName() {
        return "Courier New";
    }

    @Override
    public String toString() {
        return "Font: Courier New";
    }
}
