package Problem_2.Font;

public interface Font {
    public String getName();
    public String toString();
}
