package Problem_2.Font;

public class Monaco implements Font{
    @Override
    public String getName() {
        return "Monaco";
    }

    @Override
    public String toString() {
        return "Font: Monaco";
    }
}
