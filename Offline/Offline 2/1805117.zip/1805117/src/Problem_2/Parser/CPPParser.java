package Problem_2.Parser;

public class CPPParser implements Parser{
    @Override
    public String getName() {
        return "CPP Parser";
    }
}
