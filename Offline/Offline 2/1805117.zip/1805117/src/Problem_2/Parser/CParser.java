package Problem_2.Parser;

public class CParser implements Parser{
    @Override
    public String getName() {
        return "C Parser";
    }
}
