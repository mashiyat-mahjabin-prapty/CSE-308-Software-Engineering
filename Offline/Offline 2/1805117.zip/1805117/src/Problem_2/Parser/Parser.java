package Problem_2.Parser;

public interface Parser {
    public String getName();
}
