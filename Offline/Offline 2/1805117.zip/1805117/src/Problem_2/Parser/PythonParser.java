package Problem_2.Parser;

public class PythonParser implements Parser{
    @Override
    public String getName() {
        return "Python Parser";
    }
}
