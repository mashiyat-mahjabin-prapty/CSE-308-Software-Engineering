package Problem_1;

import java.io.File;
import java.io.IOException;

public interface tildeSum {
    public int calcTildeSum(File file) throws IOException;
}
