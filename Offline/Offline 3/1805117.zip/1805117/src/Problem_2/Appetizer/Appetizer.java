package Problem_2.Appetizer;

import Problem_2.Decorator;

public abstract class Appetizer extends Decorator {

}
