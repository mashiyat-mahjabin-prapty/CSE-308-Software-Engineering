package Problem_2.Burger;

public class Beef extends Burger{
    public Beef() {
        description = "Beef Burger";
    }
    @Override
    public int Cost() {
        return 200;
    }
}
