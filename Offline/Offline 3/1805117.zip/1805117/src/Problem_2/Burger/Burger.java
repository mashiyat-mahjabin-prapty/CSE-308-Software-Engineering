package Problem_2.Burger;

public abstract class Burger {
    protected String description;
    public String getDescription()
    {
        return description;
    }
    public abstract int Cost();
}
