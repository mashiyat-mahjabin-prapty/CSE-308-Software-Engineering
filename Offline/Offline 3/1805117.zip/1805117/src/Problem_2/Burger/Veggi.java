package Problem_2.Burger;

public class Veggi extends Burger{
    public Veggi() {
        description = "Veggi Burger";
    }
    @Override
    public int Cost() {
        return 150;
    }
}
