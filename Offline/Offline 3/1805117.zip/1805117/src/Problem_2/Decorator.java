package Problem_2;

import Problem_2.Burger.Burger;

public abstract class Decorator extends Burger {
    public abstract String getDescription();
}
