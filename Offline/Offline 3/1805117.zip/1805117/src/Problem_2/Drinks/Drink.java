package Problem_2.Drinks;

import Problem_2.Decorator;

public abstract class Drink extends Decorator {

}
